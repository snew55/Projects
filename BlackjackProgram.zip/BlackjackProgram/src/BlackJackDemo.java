import java.util.LinkedList;

public class BlackJackDemo {

    public static void main(String[] args){

        BlackJack blackJack = new BlackJack();
        blackJack.playGame();

    }
}
